/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, RotateCcw, CheckCircle2, XCircle, Music, Trophy, Volume2, ArrowRight, Activity, Zap, Copy, ExternalLink, HelpCircle } from 'lucide-react';
import confetti from 'canvas-confetti';

// --- Types ---

type ExerciseType = 'low-high' | 'high-low' | 'unison';

interface Exercise {
  freq1: number;
  freq2: number;
  correctType: ExerciseType;
}

type GameState = 'idle' | 'registering' | 'playing' | 'feedback' | 'finished' | 'teacher';

// --- Constants ---

const TOTAL_ROUNDS = 10;
const BASE_FREQS = [220, 261.63, 293.66, 329.63, 349.23, 392.00, 440.00, 493.88, 523.25]; // A3 to C5

// --- Components ---

export default function App() {
  const [gameState, setGameState] = useState<GameState>('idle');
  const [currentRound, setCurrentRound] = useState(0);
  const [score, setScore] = useState(0);
  const [currentExercise, setCurrentExercise] = useState<Exercise | null>(null);
  const [selectedAnswer, setSelectedAnswer] = useState<ExerciseType | null>(null);
  const [isAudioPlaying, setIsAudioPlaying] = useState(false);
  
  // Registration State
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  
  // Teacher State
  const [teacherPassword, setTeacherPassword] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [isTeacherLoading, setIsTeacherLoading] = useState(false);
  const [teacherError, setTeacherError] = useState('');
  const [showWixHelp, setShowWixHelp] = useState(false);

  const audioContextRef = useRef<AudioContext | null>(null);

  // Initialize Audio Context
  const getAudioContext = () => {
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    return audioContextRef.current;
  };

  const playTone = (freq: number, startTime: number, duration: number) => {
    const ctx = getAudioContext();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, startTime);

    gain.gain.setValueAtTime(0, startTime);
    gain.gain.linearRampToValueAtTime(0.3, startTime + 0.05);
    gain.gain.setValueAtTime(0.3, startTime + duration - 0.05);
    gain.gain.linearRampToValueAtTime(0, startTime + duration);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(startTime);
    osc.stop(startTime + duration);
  };

  const playExercise = useCallback((exercise: Exercise) => {
    if (isAudioPlaying) return;
    
    const ctx = getAudioContext();
    if (ctx.state === 'suspended') {
      ctx.resume();
    }

    setIsAudioPlaying(true);
    const now = ctx.currentTime;
    const toneDuration = 0.8;
    const gap = 0.4;

    playTone(exercise.freq1, now, toneDuration);
    playTone(exercise.freq2, now + toneDuration + gap, toneDuration);

    setTimeout(() => {
      setIsAudioPlaying(false);
    }, (toneDuration * 2 + gap) * 1000);
  }, [isAudioPlaying]);

  const generateExercise = (): Exercise => {
    const types: ExerciseType[] = ['low-high', 'high-low', 'unison'];
    const correctType = types[Math.floor(Math.random() * types.length)];
    
    let freq1 = BASE_FREQS[Math.floor(Math.random() * BASE_FREQS.length)];
    let freq2 = freq1;

    if (correctType === 'low-high') {
      const higherFreqs = BASE_FREQS.filter(f => f > freq1);
      if (higherFreqs.length > 0) {
        freq2 = higherFreqs[Math.floor(Math.random() * higherFreqs.length)];
      } else {
        freq2 = freq1;
        freq1 = BASE_FREQS.filter(f => f < freq2)[Math.floor(Math.random() * (BASE_FREQS.length - 1))];
      }
    } else if (correctType === 'high-low') {
      const lowerFreqs = BASE_FREQS.filter(f => f < freq1);
      if (lowerFreqs.length > 0) {
        freq2 = lowerFreqs[Math.floor(Math.random() * lowerFreqs.length)];
      } else {
        freq2 = freq1;
        freq1 = BASE_FREQS.filter(f => f > freq2)[Math.floor(Math.random() * (BASE_FREQS.length - 1))];
      }
    }

    return { freq1, freq2, correctType };
  };

  const startNewRound = () => {
    const nextExercise = generateExercise();
    setCurrentExercise(nextExercise);
    setSelectedAnswer(null);
    setGameState('playing');
    setTimeout(() => playExercise(nextExercise), 500);
  };

  const startGame = () => {
    if (!firstName || !lastName) {
      setGameState('registering');
      return;
    }
    setScore(0);
    setCurrentRound(0);
    startNewRound();
  };

  const handleAnswer = (answer: ExerciseType) => {
    if (gameState !== 'playing' || isAudioPlaying) return;
    
    setSelectedAnswer(answer);
    const isCorrect = answer === currentExercise?.correctType;
    if (isCorrect) {
      setScore(prev => prev + 1);
    }
    setGameState('feedback');
  };

  const nextStep = async () => {
    if (currentRound + 1 < TOTAL_ROUNDS) {
      setCurrentRound(prev => prev + 1);
      startNewRound();
    } else {
      const finalScore = score + (selectedAnswer === currentExercise?.correctType ? 1 : 0);
      setGameState('finished');
      confetti({
        particleCount: 150,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#06b6d4', '#22d3ee', '#ffffff']
      });

      // Send result to backend
      try {
        await fetch('/api/results', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ firstName, lastName, score: finalScore })
        });
      } catch (err) {
        console.error("Failed to save result:", err);
      }
    }
  };

  const fetchResults = async () => {
    setIsTeacherLoading(true);
    setTeacherError('');
    try {
      const resp = await fetch('/api/results', {
        headers: { 'x-teacher-password': teacherPassword }
      });
      if (!resp.ok) throw new Error("Acceso denegado");
      const data = await resp.json();
      setResults(data);
    } catch (err: any) {
      setTeacherError(err.message);
    } finally {
      setIsTeacherLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#050505] text-white font-sans selection:bg-cyan-500/30 relative overflow-hidden">
      {/* Ambient Background */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-cyan-500/10 blur-[120px] rounded-full" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-600/10 blur-[120px] rounded-full" />
      </div>

      <main className="max-w-xl mx-auto px-6 py-12 md:py-24 relative z-10">
        
        {/* Header */}
        <header className="mb-12 text-center">
          <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            onClick={() => setGameState('teacher')}
            className="inline-flex items-center justify-center w-14 h-14 rounded-full glass border-cyan-500/20 mb-4 shadow-[0_0_20px_rgba(6,182,212,0.1)] cursor-pointer"
          >
            <Activity className="w-7 h-7 text-cyan-400" />
          </motion.div>
          <h1 className="text-4xl font-bold tracking-tighter mb-1 neon-text-cyan uppercase">Auditio</h1>
          <div className="flex items-center justify-center gap-2">
            <div className="h-[1px] w-4 bg-cyan-500/50" />
            <p className="text-[10px] text-cyan-400/60 uppercase tracking-[0.3em] font-bold">Neural Audio Trainer</p>
            <div className="h-[1px] w-4 bg-cyan-500/50" />
          </div>
        </header>

        <AnimatePresence mode="wait">
          {/* Idle State */}
          {gameState === 'idle' && (
            <motion.div
              key="idle"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="glass rounded-[2rem] p-10 border-white/5 text-center"
            >
              <h2 className="text-2xl font-bold mb-4 tracking-tight">Calibración Auditiva</h2>
              <p className="text-neutral-400 mb-10 leading-relaxed text-sm">
                Analiza la frecuencia de dos señales consecutivas. Determina la relación de altura para sincronizar tu percepción auditiva.
              </p>
              
              <div className="grid grid-cols-1 gap-4 mb-10">
                {[
                  { icon: Zap, text: "10 Ciclos de entrenamiento" },
                  { icon: Activity, text: "Análisis de frecuencia diferencial" },
                  { icon: Trophy, text: "Evaluación de precisión final" }
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-4 bg-white/5 p-4 rounded-2xl border border-white/5">
                    <item.icon className="w-5 h-5 text-cyan-400" />
                    <span className="text-sm font-medium text-neutral-300">{item.text}</span>
                  </div>
                ))}
              </div>

              <button
                onClick={() => setGameState('registering')}
                className="w-full py-5 bg-cyan-500 text-black rounded-2xl font-bold hover:bg-cyan-400 transition-all flex items-center justify-center gap-3 group shadow-[0_0_30px_rgba(6,182,212,0.3)]"
              >
                INICIAR PROTOCOLO
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
            </motion.div>
          )}

          {/* Registering State */}
          {gameState === 'registering' && (
            <motion.div
              key="registering"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="glass rounded-[2rem] p-10 border-white/5"
            >
              <h2 className="text-2xl font-bold mb-6 tracking-tight text-center">Identificación de Usuario</h2>
              <div className="space-y-4 mb-8">
                <div>
                  <label className="text-[10px] font-bold uppercase tracking-widest text-neutral-500 mb-2 block">Nombre</label>
                  <input
                    type="text"
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-xl p-4 text-white focus:border-cyan-500 outline-none transition-colors"
                    placeholder="Ej. Juan"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold uppercase tracking-widest text-neutral-500 mb-2 block">Apellido</label>
                  <input
                    type="text"
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-xl p-4 text-white focus:border-cyan-500 outline-none transition-colors"
                    placeholder="Ej. Pérez"
                  />
                </div>
              </div>
              <button
                onClick={startGame}
                disabled={!firstName || !lastName}
                className="w-full py-5 bg-cyan-500 text-black rounded-2xl font-bold hover:bg-cyan-400 transition-all flex items-center justify-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                CONFIRMAR Y EMPEZAR
              </button>
            </motion.div>
          )}

          {/* Playing / Feedback State */}
          {(gameState === 'playing' || gameState === 'feedback') && (
            <motion.div
              key="game"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.02 }}
              className="space-y-6"
            >
              {/* Progress Bar */}
              <div className="glass rounded-2xl p-5 border-white/5 flex items-center justify-between">
                <div className="flex flex-col">
                  <span className="text-[10px] font-mono text-cyan-400/50 uppercase tracking-widest">Secuencia</span>
                  <span className="text-xl font-bold font-mono">{String(currentRound + 1).padStart(2, '0')} / {TOTAL_ROUNDS}</span>
                </div>
                <div className="flex-1 mx-8 h-1 bg-white/5 rounded-full overflow-hidden relative">
                  <motion.div 
                    className="h-full bg-cyan-500 shadow-[0_0_10px_rgba(6,182,212,0.5)]"
                    initial={{ width: 0 }}
                    animate={{ width: `${((currentRound + 1) / TOTAL_ROUNDS) * 100}%` }}
                  />
                </div>
                <div className="flex flex-col items-end">
                  <span className="text-[10px] font-mono text-cyan-400/50 uppercase tracking-widest">Score</span>
                  <span className="text-xl font-bold font-mono text-cyan-400">{score}</span>
                </div>
              </div>

              {/* Main Interaction Area */}
              <div className="glass rounded-[2.5rem] p-10 border-white/5 text-center relative overflow-hidden">
                <div className="mb-10 relative">
                  <div className={`absolute inset-0 bg-cyan-500/20 blur-[60px] rounded-full transition-opacity duration-500 ${isAudioPlaying ? 'opacity-100' : 'opacity-0'}`} />
                  <button
                    onClick={() => currentExercise && playExercise(currentExercise)}
                    disabled={isAudioPlaying}
                    className={`w-28 h-28 rounded-full flex items-center justify-center mx-auto transition-all relative z-10 ${
                      isAudioPlaying 
                        ? 'bg-cyan-500 text-black scale-110 shadow-[0_0_40px_rgba(6,182,212,0.4)]' 
                        : 'bg-white/5 text-cyan-400 hover:bg-white/10 border border-cyan-500/20'
                    }`}
                  >
                    {isAudioPlaying ? (
                      <Volume2 className="w-12 h-12 animate-pulse" />
                    ) : (
                      <Play className="w-12 h-12 ml-1" />
                    )}
                  </button>
                  <p className={`mt-6 text-[10px] font-bold uppercase tracking-[0.4em] transition-colors ${isAudioPlaying ? 'text-cyan-400' : 'text-neutral-500'}`}>
                    {isAudioPlaying ? 'Procesando Señal...' : 'Emitir Frecuencias'}
                  </p>
                </div>

                <div className="grid grid-cols-1 gap-4">
                  {[
                    { id: 'low-high', label: 'GRAVE / AGUDO', sub: 'Ascendente' },
                    { id: 'high-low', label: 'AGUDO / GRAVE', sub: 'Descendente' },
                    { id: 'unison', label: 'UNÍSONO', sub: 'Frecuencia Constante' }
                  ].map((opt) => {
                    const isCorrect = opt.id === currentExercise?.correctType;
                    const isSelected = opt.id === selectedAnswer;
                    
                    let buttonClass = "w-full p-6 rounded-2xl border transition-all text-left flex items-center justify-between group relative overflow-hidden ";
                    
                    if (gameState === 'feedback') {
                      if (isCorrect) buttonClass += "bg-cyan-500/10 border-cyan-500/50 text-cyan-400 ";
                      else if (isSelected) buttonClass += "bg-red-500/10 border-red-500/50 text-red-400 ";
                      else buttonClass += "bg-transparent border-white/5 opacity-20 ";
                    } else {
                      buttonClass += "bg-white/5 border-white/10 hover:border-cyan-500/50 hover:bg-white/10 ";
                    }

                    return (
                      <button
                        key={opt.id}
                        onClick={() => handleAnswer(opt.id as ExerciseType)}
                        disabled={gameState === 'feedback' || isAudioPlaying}
                        className={buttonClass}
                      >
                        <div className="relative z-10">
                          <p className="font-bold tracking-wider text-sm">{opt.label}</p>
                          <p className="text-[10px] opacity-50 font-mono uppercase mt-1">{opt.sub}</p>
                        </div>
                        <div className="relative z-10">
                          {gameState === 'feedback' && isCorrect && <CheckCircle2 className="w-6 h-6 text-cyan-400" />}
                          {gameState === 'feedback' && isSelected && !isCorrect && <XCircle className="w-6 h-6 text-red-500" />}
                        </div>
                        {gameState !== 'feedback' && !isAudioPlaying && (
                          <div className="absolute inset-0 bg-cyan-500/0 group-hover:bg-cyan-500/5 transition-colors" />
                        )}
                      </button>
                    );
                  })}
                </div>

                {/* Feedback Overlay */}
                <AnimatePresence>
                  {gameState === 'feedback' && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="mt-10 pt-8 border-t border-white/5"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`w-2 h-2 rounded-full animate-pulse ${selectedAnswer === currentExercise?.correctType ? 'bg-cyan-500' : 'bg-red-500'}`} />
                          <span className={`text-xs font-bold uppercase tracking-widest ${selectedAnswer === currentExercise?.correctType ? 'text-cyan-400' : 'text-red-400'}`}>
                            {selectedAnswer === currentExercise?.correctType ? 'Sincronización Exitosa' : 'Error de Calibración'}
                          </span>
                        </div>
                        <button
                          onClick={nextStep}
                          className="px-8 py-3 bg-white text-black rounded-xl text-xs font-bold uppercase tracking-widest hover:bg-neutral-200 transition-all flex items-center gap-2"
                        >
                          Continuar <ArrowRight className="w-4 h-4" />
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>
          )}

          {/* Finished State */}
          {gameState === 'finished' && (
            <motion.div
              key="finished"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="glass rounded-[3rem] p-12 border-white/5 text-center relative overflow-hidden"
            >
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-cyan-500 to-transparent" />
              
              <div className="w-24 h-24 bg-cyan-500/10 rounded-full flex items-center justify-center mx-auto mb-8 border border-cyan-500/20 shadow-[0_0_30px_rgba(6,182,212,0.1)]">
                <Trophy className="w-12 h-12 text-cyan-400" />
              </div>
              
              <h2 className="text-3xl font-bold mb-2 tracking-tighter uppercase">Análisis Finalizado</h2>
              <p className="text-neutral-500 mb-10 text-sm">Protocolo de entrenamiento auditivo completado con éxito.</p>
              
              <div className="bg-white/5 rounded-[2rem] p-10 mb-10 border border-white/5 relative">
                <div className="absolute inset-0 bg-cyan-500/5 blur-[40px] rounded-full" />
                <p className="text-[10px] text-cyan-400/50 uppercase tracking-[0.4em] font-bold mb-4 relative z-10">Precisión de Red</p>
                <div className="flex items-baseline justify-center gap-2 relative z-10">
                  <span className="text-8xl font-black tracking-tighter neon-text-cyan">{score}</span>
                  <span className="text-3xl text-neutral-600 font-bold">/ 10</span>
                </div>
                <div className="mt-8 relative z-10">
                  <p className="text-sm font-medium text-neutral-300">
                    {score === 10 ? "PERFECCIÓN ABSOLUTA. SISTEMA OPTIMIZADO." : 
                     score >= 8 ? "ALTA PRECISIÓN DETECTADA." :
                     score >= 5 ? "CALIBRACIÓN EN PROGRESO." :
                     "RECALIBRACIÓN REQUERIDA."}
                  </p>
                </div>
              </div>

              <button
                onClick={() => setGameState('idle')}
                className="w-full py-5 bg-white/5 text-white border border-white/10 rounded-2xl font-bold uppercase tracking-widest hover:bg-white/10 transition-all flex items-center justify-center gap-3"
              >
                <RotateCcw className="w-5 h-5" /> Reiniciar Protocolo
              </button>
            </motion.div>
          )}

          {/* Teacher State */}
          {gameState === 'teacher' && (
            <motion.div
              key="teacher"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="glass rounded-[2rem] p-8 border-white/5"
            >
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-2xl font-bold tracking-tight">Panel del Docente</h2>
                <button onClick={() => setGameState('idle')} className="text-neutral-500 hover:text-white transition-colors">
                  <XCircle className="w-6 h-6" />
                </button>
              </div>

              {results.length === 0 ? (
                <div className="space-y-6">
                  <div>
                    <label className="text-[10px] font-bold uppercase tracking-widest text-neutral-500 mb-2 block">Contraseña de Acceso</label>
                    <input
                      type="password"
                      value={teacherPassword}
                      onChange={(e) => setTeacherPassword(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-xl p-4 text-white focus:border-cyan-500 outline-none transition-colors"
                      placeholder="••••••••"
                    />
                  </div>
                  {teacherError && <p className="text-red-500 text-xs font-bold uppercase tracking-widest">{teacherError}</p>}
                  <button
                    onClick={fetchResults}
                    disabled={isTeacherLoading || !teacherPassword}
                    className="w-full py-4 bg-cyan-500 text-black rounded-xl font-bold hover:bg-cyan-400 transition-all disabled:opacity-50"
                  >
                    {isTeacherLoading ? 'AUTENTICANDO...' : 'VER CALIFICACIONES'}
                  </button>
                </div>
              ) : (
                <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                  {results.map((res: any) => (
                    <div key={res.id} className="bg-white/5 border border-white/10 rounded-xl p-4 flex items-center justify-between">
                      <div>
                        <p className="font-bold text-sm uppercase tracking-wider">{res.firstName} {res.lastName}</p>
                        <p className="text-[10px] text-neutral-500 font-mono">{new Date(res.timestamp).toLocaleString()}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`text-xl font-black font-mono ${res.score >= 8 ? 'text-cyan-400' : res.score >= 5 ? 'text-amber-400' : 'text-red-400'}`}>
                          {res.score}
                        </span>
                        <span className="text-[10px] text-neutral-600 font-bold">/ 10</span>
                      </div>
                    </div>
                  ))}
                  <button
                    onClick={() => setResults([])}
                    className="w-full py-3 bg-white/5 text-neutral-400 rounded-xl text-[10px] font-bold uppercase tracking-widest hover:bg-white/10 transition-all mb-4"
                  >
                    CERRAR SESIÓN
                  </button>

                  <div className="pt-4 border-t border-white/5">
                    <button 
                      onClick={() => setShowWixHelp(!showWixHelp)}
                      className="flex items-center gap-2 text-[10px] font-bold text-cyan-400/60 hover:text-cyan-400 transition-colors uppercase tracking-widest"
                    >
                      <HelpCircle className="w-3 h-3" /> ¿Problemas con Wix?
                    </button>
                    
                    {showWixHelp && (
                      <motion.div 
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        className="mt-4 p-4 bg-cyan-500/5 rounded-xl border border-cyan-500/10 text-left"
                      >
                        <p className="text-[10px] text-neutral-400 leading-relaxed mb-4">
                          Si Wix rechaza la conexión, asegúrate de usar la URL compartida y NO la del editor de Google.
                        </p>
                        <button
                          onClick={() => {
                            navigator.clipboard.writeText('https://ais-pre-xb52dtf7szzdm75pp7kwhx-308412418483.us-east1.run.app');
                            alert('URL copiada al portapapeles');
                          }}
                          className="w-full py-3 bg-cyan-500/20 text-cyan-400 rounded-lg text-[10px] font-bold uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-cyan-500/30 transition-all"
                        >
                          <Copy className="w-3 h-3" /> Copiar URL para Wix
                        </button>
                      </motion.div>
                    )}
                  </div>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Footer */}
        <footer className="mt-16 text-center">
          <div className="flex items-center justify-center gap-4 mb-4 opacity-20">
            <div className="h-[1px] flex-1 bg-white" />
            <Activity className="w-4 h-4" />
            <div className="h-[1px] flex-1 bg-white" />
          </div>
          <p className="text-[9px] text-neutral-600 uppercase tracking-[0.5em] font-bold">
            Auditio OS // v2.0.4 // Neural Interface
          </p>
        </footer>
      </main>
    </div>
  );
}
