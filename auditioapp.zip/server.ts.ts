import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("auditio.db");
db.exec(`
  CREATE TABLE IF NOT EXISTS results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    firstName TEXT NOT NULL,
    lastName TEXT NOT NULL,
    score INTEGER NOT NULL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
  )
`);

async function startServer() {
  const app = express();
  const PORT = process.env.PORT || 3000;

  app.use((req, res, next) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Content-Security-Policy", "frame-ancestors *;");
    res.removeHeader("X-Frame-Options");
    next();
  });

  app.use(express.json());

  app.post("/api/results", (req, res) => {
    const { firstName, lastName, score } = req.body;
    const stmt = db.prepare("INSERT INTO results (firstName, lastName, score) VALUES (?, ?, ?)");
    stmt.run(firstName, lastName, score);
    res.json({ success: true });
  });

  app.get("/api/results", (req, res) => {
    const password = req.headers["x-teacher-password"];
    if (password !== process.env.TEACHER_PASSWORD) return res.status(401).send("Unauthorized");
    const results = db.prepare("SELECT * FROM results ORDER BY timestamp DESC").all();
    res.json(results);
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({ server: { middlewareMode: true }, appType: "spa" });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => res.sendFile(path.join(__dirname, "dist", "index.html")));
  }

  app.listen(PORT, "0.0.0.0", () => console.log(`Server on ${PORT}`));
}
startServer();