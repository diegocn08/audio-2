import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("auditio.db");

// Initialize database
db.exec(`
  CREATE TABLE IF NOT EXISTS results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    firstName TEXT NOT NULL,
    lastName TEXT NOT NULL,
    score INTEGER NOT NULL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
  )
`);

async function startServer() {
  const app = express();
  const PORT = process.env.PORT || 3000;

  // Permissive headers for external embedding (Wix, etc.)
  app.use((req, res, next) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, x-teacher-password");
    res.setHeader("Content-Security-Policy", "frame-ancestors *;");
    res.removeHeader("X-Frame-Options");
    if (req.method === "OPTIONS") {
      return res.sendStatus(200);
    }
    next();
  });

  app.use(express.json());

  // API Routes
  app.post("/api/results", (req, res) => {
    const { firstName, lastName, score } = req.body;
    if (!firstName || !lastName || score === undefined) {
      return res.status(400).json({ error: "Missing data" });
    }

    try {
      const stmt = db.prepare("INSERT INTO results (firstName, lastName, score) VALUES (?, ?, ?)");
      stmt.run(firstName, lastName, score);
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: "Failed to save result" });
    }
  });

  app.get("/api/results", (req, res) => {
    const password = req.headers["x-teacher-password"];
    if (password !== process.env.TEACHER_PASSWORD) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    try {
      const results = db.prepare("SELECT * FROM results ORDER BY timestamp DESC").all();
      res.json(results);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch results" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
